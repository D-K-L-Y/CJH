﻿using System;
using System.Collections.Generic;

namespace RJGZJC_3_1
{
    class Program
    {
        public class Node<T>
        {
            public Node<T> Next
            {
                get;
                set;
            }
            public T Data
            {
                get;
                set;
            }
            public Node(T t)
            {
                Next = null;
                Data = t;
            }
        }

        public class GenericList<T>
        {
            private Node<T> head;
            private Node<T> tail;
            private Node<T> node;
            public GenericList()
            {
                tail = head = null;
            }
            public Node<T> Head
            {
                get => head;
            }
            public void Add(T t)
            {
                Node<T> n = new Node<T>(t);
                if (tail == null)
                {
                    head = tail = n;
                }
                else
                {
                    tail.Next = n;
                    tail = n;
                }
            }
            public void Forea(ref List<T> l)
            {
                int i = 0;
                node = this.Head;
                for (node = this.Head; node != null; node = node.Next)
                {
                    l.Add(node.Data);
                    i++;
                }
 /*               do
                {
                    i = node.Data;
                    return i;
                    node = node.Next;
                    Console.WriteLine(i);
                } while (node != null);*/
            }

        }

        static void Main(string[] args)
        {
            List<int> l = new List<int>(20);
            GenericList<int> intlist = new GenericList<int>();
            for (int x = 0; x < 10; x++)
            {
                intlist.Add(x);
            }
            intlist.Forea(ref l);
            Console.WriteLine("打印链表元素:");
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(l[i]);
            }
            int max, min;
            max = l[0];
            min = l[0];
            int sum = 0;
            for (int i = 0; i < 10; i++)
            {
                if(max < l[i])
                {
                    max = l[i];
                }
                if(min > l[i])
                {
                    min = l[i];
                }
                sum += l[i];
            }
            Console.WriteLine("最大值为：" + max);
            Console.WriteLine("最小值为：" + min);
            Console.WriteLine("和为：" + sum);
        }
    }
}


    

