﻿using System;

namespace RJGZJC_3_2
{
    class Program
    {
        class Ala
        {
            public delegate void AlarmEventHandler(object sender, EventArgs e);

            public event AlarmEventHandler Alarm;

            public void OnAlarm()
            {
                if (this.Alarm != null)
                {
                    Console.WriteLine("闹钟响铃-Alarm!");
                    this.Alarm(this, new EventArgs());
                }
            }
        }

        class User
        {
            void UserHandleAram(object sender,EventArgs e)
            {
                Console.WriteLine("用户关闭了闹钟");
            }

            public User(Ala alarm)
            {
                alarm.Alarm += new Ala.AlarmEventHandler(UserHandleAram);
            }
        }
        
        static void Main(string[] args)
        {        
            Ala ala = new Ala();
            User user = new User(ala);
            int x = 0;
            Console.WriteLine("请设置闹钟时间（单位：秒；0~60之间）：");
            x = Convert.ToInt32(Console.ReadLine());
            int y = DateTime.Now.Year;
            int m = DateTime.Now.Month;
            int d = DateTime.Now.Day;
            int h = DateTime.Now.Hour;
            int m2 = DateTime.Now.Minute;
            int s = DateTime.Now.Second;
            DateTime now = DateTime.Now;
            DateTime alatime = now.AddSeconds(x);

            while (now < alatime)
            {
                Console.WriteLine("时间为：" + now);
                Console.WriteLine("Tick...Tick...");
                System.Threading.Thread.Sleep(1000);
                now = now.AddSeconds(1);
            }
            ala.OnAlarm();

        }
    }
}
