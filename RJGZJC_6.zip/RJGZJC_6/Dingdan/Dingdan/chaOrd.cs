﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Dingdan
{
    public partial class chaOrd : Form
    {
        string ID = "";
        public chaOrd()
        {
            InitializeComponent();
        }
        public chaOrd(string id, string name, string client, string money)
        {
            InitializeComponent();
            ID = textBox1.Text = id;
            textBox2.Text = name;
            textBox3.Text = client;
            textBox4.Text = money;
        }

        private void chaOrd_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = $"update t_ordForm set id = '{textBox1.Text}',[name] = '{textBox2.Text}',client = '{textBox3.Text}',[money]='{textBox4.Text}' where id ='{ID}'";
            Dao dao = new Dao();
            if (dao.Execute(sql) > 0)
            {
                MessageBox.Show("修改成功");
                this.Close();
            }
            else
            {
                MessageBox.Show("修改失败");
            }

        }
    }
}