﻿using System.Data;
using System.Data.SqlClient;

namespace Dingdan
{
    class Dao
    {
        SqlConnection sc;
         public SqlConnection connect()
        {
            string str = @"Data Source=LAPTOP-RT55FUV2;Initial Catalog=DindanDB;Integrated Security=True";
            sc = new SqlConnection(str);
            sc.Open();
            return sc;
        }
        public SqlCommand command(string sql)
        {
            SqlCommand cmd = new SqlCommand(sql, connect());
            return cmd;
        }
        public int Execute(string sql)
        {
            return command(sql).ExecuteNonQuery();
        }
        public SqlDataReader read(string sql)
        {
            return command(sql).ExecuteReader();
        }
        public void DaoClose()
        {
            sc.Close();
        }
    }
}
