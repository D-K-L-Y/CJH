﻿using System;

namespace RJGZJC_2_4
{
    class Program
    {
        abstract class Shape {
            public abstract double Mj();
            public abstract void New();
        }

        class Rect : Shape
        {
            double lon,sho,are;
            
             public override void New()
            {
                Random ran = new Random();
                lon = ran.Next(1, 10);
                sho = ran.Next(1, 10);
                Console.WriteLine("创建了一个长为：" + lon + "宽为：" + sho + "的长方形");
            }

            public override double Mj()
            {
                are = lon * sho;
                Console.WriteLine("本长方形的面积为：" + are);
                return are;
            }
        }

        class Squa : Shape
        {
            double lon, are;

            public override void New()
            {
                Random ran = new Random();
                lon = ran.Next(1, 10);
                Console.WriteLine("创建了一个长为：" + lon  + "的正方形");
            }

            public override double Mj()
            {
                are = lon * lon;
                Console.WriteLine("本正方形的面积为：" + are);
                return are;
            }
        }

        class Tri : Shape
        {
            double lon1, lon2, lon3, are;

            public override void New()
            {
                Random ran = new Random();
                lon1 = ran.Next(1, 10);
                lon2 = ran.Next(1, 10);
                lon3 = ran.Next(1, 10);
                if (!(lon1 + lon2 > lon3 && lon1 - lon2 < lon3))
                {
                    Console.WriteLine("随机生成的数字无法组成三角形");
                    lon1 = 0;
                    lon2 = 0;
                    lon3 = 0;
                    return;
                }else
                {
                    Console.WriteLine("创建了一个三个边长分别为：" + lon1 + " " + lon2 + " " + lon3 + "的三角形");
                }
            }

            public override double Mj()
            {
                double l = (lon1 + lon2 + lon3) / 2;
                double num = l * (l - lon1) * (l - lon2) * (l - lon3);
                are = Math.Sqrt(num);
                Console.WriteLine("本三角形的面积为：" + are);
                return are;
            }
        }

        class Factory
        {
            public static  Shape CreateFunction(string name)
            {
                switch (name)
                {
                    case "rect":return new Rect();
                    case "squa": return new Squa();
                    case "tri": return new Tri();
                    default:
                        return null;
                }
            }
        }
        static void Main(string[] args)
        {
            string rec = "rect";
            string squ = "squa";
            Shape a = Factory.CreateFunction(rec);
            Shape b = Factory.CreateFunction(rec);
            Shape c = Factory.CreateFunction(rec);
            Shape d = Factory.CreateFunction(rec);
            Shape e = Factory.CreateFunction(rec);
            Shape f = Factory.CreateFunction(squ);
            Shape g = Factory.CreateFunction(squ);
            Shape h = Factory.CreateFunction(squ);
            Shape i = Factory.CreateFunction(squ);
            Shape j = Factory.CreateFunction(squ);
            a.New();
            b.New();
            c.New();
            d.New();
            e.New();
            f.New();
            g.New();
            h.New();
            i.New();
            j.New();
            double sum = a.Mj() + b.Mj() + c.Mj() + d.Mj() + e.Mj() + f.Mj() + g.Mj() + h.Mj() + i.Mj() + j.Mj();
            Console.WriteLine("面积之和为：" + sum);
        }
    }
}
