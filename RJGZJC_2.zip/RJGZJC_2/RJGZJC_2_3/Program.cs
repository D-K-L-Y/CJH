﻿using System;
using System.Collections.Generic;

namespace RJGZJC_2_3
{
    class Program
    {
        static void Main(string[] args)
        {

            bool[] fac = new bool[100];
            for(int i = 2; i < 100; i++)
            {
                for(int j = i*2; j < 100; j = j+i)
                {
                        fac[j] = true;
                }
            }
            Console.WriteLine("2~100内的素数为：");
            for(int i = 0; i < fac.Length; i++)
            {
                if (fac[i] == false)
                {
                    Console.WriteLine(i);
                }
            }
        }
    }
}
