﻿using System;

namespace RJGZJC_2_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[5];
            for(int i = 0;i < 5; i++)
            {
                Console.WriteLine("请输入第"+ (i + 1)+"个数字");
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("输出数组：");
            for(int i = 0; i < 5; i++)
            {
                Console.WriteLine(arr[i]);
            }
            GetMax(arr);
            GetMin(arr);
            GetSum(arr);
        }
        static void GetMax(int[] array)
        {
            int max = 0;
            for(int i = 0; i < array.Length; i++)
            {
                if(max < array[i])
                {
                    max = array[i];
                }
            }
            Console.WriteLine("数组的最大值为：" + max);
        }

        static void GetMin(int[] array)
        {
            int min = 1000;
            for (int i = 0; i < array.Length; i++)
            {
                if (min > array[i])
                {
                    min = array[i];
                }
            }
            Console.WriteLine("数组的最小值为：" + min);
        }

        static void GetSum(int[] array)
        {
            int sum = 0;
            for (int i = 0; i < array.Length; i++)
            {
                sum += array[i];
            }
            Console.WriteLine("数组的和为：" + sum);
            Console.WriteLine("数组的平均数为：" + (sum / array.Length));
        }
    }
}
