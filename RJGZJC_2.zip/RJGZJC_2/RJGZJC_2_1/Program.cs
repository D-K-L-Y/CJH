﻿using System;
using System.Collections.Generic;

namespace RJGZJC_2_1
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> res = new List<int>();
            Console.WriteLine("请输入一个正整数");
            int number = Convert.ToInt32(Console.ReadLine());
            for (int a = 2;a < number; a++)
            {
                while(number % a == 0 && a != number)
                {
                    res.Add(a);
                    number = number / a;
                }
            }
            res.Add(number);
            Console.WriteLine("质因数为：");
             foreach(var ans in res)
            {
                Console.WriteLine(ans);
            }
        }
    }
}
