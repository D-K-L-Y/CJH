﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading;

namespace RJGZJC_7
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != null)
            {
                try
                {
                    System.Net.WebClient client = new WebClient();
                    string staUrl = textBox1.Text;
                    byte[] page = client.DownloadData(staUrl);
                    string content = System.Text.Encoding.UTF8.GetString(page);
                    string regex = "href=[\\\"\\\'](http:\\/\\/|\\.\\/|\\/)?\\w+(\\.\\w+)*(\\/\\w+(\\.\\w+)?)*(\\/|\\?\\w*=\\w*(&\\w*=\\w*)*)?[\\\"\\\']";
                    Regex re = new Regex(regex);
                    MatchCollection matches = re.Matches(content);
                    System.Collections.IEnumerator enu = matches.GetEnumerator();
                    while (enu.MoveNext() && enu.Current != null)
                    {
                        Match match = (Match)(enu.Current);
                        textBox2.Text += match.Value + "\r\n";
                    }

                }
                catch
                {
                    MessageBox.Show("请输入正确的网址");
                }
            }
            else
            {
                MessageBox.Show("请输入网址");
            }
        }
    }
}
