﻿using System;
namespace GZJC1_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("请输入第一个数字：");
            double a = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("请输入运算符号（+，-，*，/，%）：");
            string b = Console.ReadLine();
            Console.WriteLine("请输入第二个数字：");
            double c = Convert.ToDouble(Console.ReadLine());
            double d;
            if (b == "+")
            {
                d = a + c;
                Console.WriteLine("=" + d);
            }
            if (b == "-")
            {
                d = a - c;
                Console.WriteLine("=" + d);
            }
            if (b == "*")
            {
                d = a * c;
                Console.WriteLine("=" + d);
            }
            if (b == "/")
            {
                if (c == 0)
                {
                    Console.WriteLine("除数不能为0");
                }
                else
                {
                    d = a / c;
                    Console.WriteLine("=" + d);
                }
            }
            if (b == "%")
            {
                d = a % c;
                Console.WriteLine("=" + d);
            }
        }
    }

}

